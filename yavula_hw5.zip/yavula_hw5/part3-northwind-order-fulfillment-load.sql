/* Yesaswi Avula and Christy Sato */




use ist722_yavula_dw

delete from [northwind].[DimEmployee]
delete from [northwind].[DimCustomer]
delete from [northwind].[DimProduct]
delete from [northwind].[DimShippers]
delete from [northwind].[FactOrderFulfillemnt]
delete from [northwind].[DimDate]
drop table stgNorthwindOrderFulfilment




-- load DimEmployee
INSERT INTO [northwind].[DimEmployee]
             ([EmployeeID],[EmployeeName],[EmployeeTitle])
SELECT EmployeeID, FirstName + ' ' + LastName as EmployeeName, [Title]
        FROM [ist722_yavula_stage].[dbo].[stgNorthwindEmployees]

		/* SELECT * FROM [northwind].[DimEmployee]*/

--load  DimCustomer
INSERT INTO [Northwind].[DimCustomer]
  ([CustomerID],[CompanyName],[ContactName],[ContactTitle],
  [CustomerCountry], [CustomerRegion], [CustomerCity],[CustomerPostalCode])
SELECT 
    [CustomerID], [CompanyName], [ContactName], [ContactTitle], [Country],
	case when Region is null then 'N/A' else [Region] end,
	[City],
	case when [PostalCode] is null then 'N/A'else [PostalCode] end
  FROM [ist722_yavula_stage].[dbo].[stgNorthwindCustomers]

  SELECT * FROM [northwind].[DimCustomer]

  
  --load DimProduct
  INSERT INTO [Northwind].[DimProduct]
  ([ProductID], [ProductName], [Discontinued],[SupplierName], [CategoryName])
  SELECT 
   [ProductID], [ProductName],
   case when [Discontinued]= '1' then 'Y' else 'N' END,
   [CompanyName], [CategoryName]
   FROM [ist722_yavula_stage].[dbo].[stgNorthwindProducts]

   --Load DimDate
   SELECT * FROM [ist722_yavula_stage].[dbo].[stgNorthwindDates]

   INSERT INTO [northwind].[DimDate]
   ([DateKey],[Date], [FullDateUSA], [DayOfWeek], [DayName], [DayOfMonth], [DayOfYear], [WeekOfYear], [MonthName], [MonthOfYear], 
    [Quarter], [QuarterName],[Year], [IsWeekday])
	SELECT 
	[DateKey],[Date], [FullDateUSA], [DayOfWeekUSA], [DayName], [DayOfMonth], [DayOfYear], [WeekOfYear], [MonthName], [Month], 
    [Quarter],[QuarterName], [Year], [IsWeekday]
	FROM [ist722_yavula_stage].[dbo].[stgNorthwindDates]


	SELECT s.*, c.CustomerKey
	  FROM [ist722_yavula_stage].[dbo].[stgNorthwindSales] s
	   join [ist722_yavula_dw].[northwind].DimCustomer c
	      on s.CustomerID=c.CustomerID

--creating the view
--loading Shippers
INSERT INTO [northwind].[DimShippers]
            ([ShipperID], [CompanyName])
Select [ShipperID], [CompanyName]
FROM [ist722_yavula_stage].[dbo].[stgNorthwindShippers];

--loading OrderFulfilment
/*
INSERT INTO [dbo].[stgNorthwindOrderFulfilment]
([ProductKey], [CustomerKey], [ShipperKey]
,[OrderDateKey]
,[ShippedDateKey]
,[OrderID] 
,[Quantity] 
,[DaysElapsed])
SELECT p.ProductKey, c.CustomerKey, s.ShipperKey,
   [ExternalSources2].dbo.[getDateKey](oful.OrderDate) as OrderDateKey,
   case when [ExternalSources2].[dbo].[getDateKey](oful.ShippedDate) is null then -1
   else [ExternalSources2].[dbo].[getDateKey](oful.ShippedDate) end as ShippedDateKey,
   oful.OrderID,
   Quantity,
   case when oful.ShippedDate is null then -1 else DATEDIFF(DAYOFYEAR, oful.OrderDate,oful.ShippedDate) end as 'Number of Days Elapsed'
FROM [ist722_yavula_stage].[dbo].stgNorthwindOrderFulfilment oful
join [ist722_yavula_dw].northwind.DimCustomer c
on oful.CustomerID = c.CustomerID
join [ist722_yavula_dw].northwind.DimShippers s
on oful.ShipperID = s.ShipperID
join [ist722_yavula_dw].northwind.DimProduct p
on oful.ProductID = p.ProductID
*/


---stage Orderfulfillment fact
SELECT d.[OrderID] as OrderFullfillmentID
	, [CustomerID]
	,[EmployeeID]
	,[OrderDate]
	,[ShippedDate]
	/* ,[ShipVia] */
	,[Quantity]
into [dbo].[stgNorthwindOrderFulfilment]
FROM [Northwind].[dbo].[Order Details] d
	join [Northwind].[dbo].[Orders] o
		on o.[OrderID] = d.[OrderID]

